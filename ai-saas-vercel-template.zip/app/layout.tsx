
export const metadata = {
  title: "AI Content Repurposer SaaS",
  description: "Turn one piece of content into multiple social posts"
}

export default function RootLayout({ children }) {
  return (
    <html>
      <body style={{fontFamily:"Arial",padding:"40px"}}>
        {children}
      </body>
    </html>
  )
}
