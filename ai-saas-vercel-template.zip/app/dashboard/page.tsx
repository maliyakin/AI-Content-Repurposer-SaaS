
"use client"

import { useState } from "react"

export default function Dashboard(){

  const [input,setInput] = useState("")
  const [result,setResult] = useState("")

  async function generate(){

    const res = await fetch("/api/generate",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({content:input})
    })

    const data = await res.json()
    setResult(data.result)
  }

  return (

    <div>

      <h1>AI Content Generator</h1>

      <textarea
        rows="6"
        style={{width:"100%"}}
        placeholder="Paste your content here"
        value={input}
        onChange={(e)=>setInput(e.target.value)}
      />

      <br/><br/>

      <button onClick={generate}>
        Generate Content
      </button>

      <pre style={{whiteSpace:"pre-wrap",marginTop:"30px"}}>
        {result}
      </pre>

    </div>

  )

}
