
export async function POST(req){

  const {content} = await req.json()

  const output = `
Twitter Thread:
1. ${content}

LinkedIn Post:
Here is a professional version of your idea:
${content}

Instagram Caption:
🔥 ${content} #content #creator

Blog Outline:
1. Introduction
2. Main Idea
3. Examples
4. Conclusion
`

  return Response.json({
    result:output
  })

}
