
import Link from "next/link"

export default function Home(){

  return (
    <main>

      <h1 style={{fontSize:"42px",fontWeight:"bold"}}>
        AI Content Repurposer
      </h1>

      <p>Turn one idea into 10 pieces of content instantly.</p>

      <br/>

      <Link href="/dashboard">
        <button style={{padding:"12px 20px",fontSize:"18px"}}>
          Open Dashboard
        </button>
      </Link>

    </main>
  )
}
